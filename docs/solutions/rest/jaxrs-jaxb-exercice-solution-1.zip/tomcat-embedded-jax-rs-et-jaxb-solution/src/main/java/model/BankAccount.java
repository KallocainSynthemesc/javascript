package model;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "bankaccount")
@XmlAccessorType(XmlAccessType.FIELD)
public class BankAccount {

	@XmlAttribute
    private int accountIdentifier;
	
	@XmlElement
	private Person accountOwner;
	
	@XmlElement
    private Person bankConsultant;
	
	@XmlElement
    private String bankName;
    
    public BankAccount() {}

	public BankAccount(int accountIdentifier, Person accountOwner, Person bankConsultant, String bankName) {
    	this.accountOwner = accountOwner;
    	this.bankConsultant = bankConsultant;
    	this.bankName = bankName;
    	this.accountIdentifier = accountIdentifier;
    }
    
    public int getAccountIdentifier() {
    	return accountIdentifier;
    }
    
    public void setAccountIdentifier(int accountIdentifier) {
    	this.accountIdentifier = accountIdentifier;
    }
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Person getBankConsultant() {
		return bankConsultant;
	}
	public void setBankConsultant(Person bankConsultant) {
		this.bankConsultant = bankConsultant;
	}
	public Person getAccountOwner() {
		return accountOwner;
	}
	public void setAccountOwner(Person accountOwner) {
		this.accountOwner = accountOwner;
	}
	
    @Override
	public String toString() {
		return "BankAccount [accountIdentifier=" + accountIdentifier + ", accountOwner=" + accountOwner
				+ ", bankConsultant=" + bankConsultant + ", bankName=" + bankName + "]";
	}
}
