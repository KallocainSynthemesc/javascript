package api;

import javax.ws.rs.Path;

@Path("/bankaccount")
public class BankAccountResource {
	
	
}