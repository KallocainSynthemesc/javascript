package api;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import dao.PersonList;
import model.Person;

@Path("/persons")
public class PersonResource {
	
	@GET
	public String getPersonList() {
		System.out.println(PersonList.persons);
        return PersonList.persons.toString();
	}
	
    @GET
    @Path("{id}")
    public String getPersonById(@PathParam("id") long id) {
        Person resultPers = null;
        for (Person p : PersonList.persons) {
            if (p.getPersonNum() == id) {
                resultPers = p;
                break;
            }
        }
        if (resultPers == null) {
            throw new NotFoundException("Person with ID " + id + " not found");
        }
        return resultPers.toString();
    }
	
	@POST
	public String addPerson(@FormParam("firstName") String firstName,
	                        @FormParam("lastName") String lastName,
	                        @FormParam("age") int age) {
		long id = PersonList.persons.size();
	    Person newPers = new Person(id, firstName, lastName, age);
	    PersonList.persons.add(newPers);
	    return newPers.toString();
	}
}