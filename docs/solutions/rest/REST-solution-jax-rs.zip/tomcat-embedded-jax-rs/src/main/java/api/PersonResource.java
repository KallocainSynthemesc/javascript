package api;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import dao.PersonList;
import model.Person;

@Path("/persons")
public class PersonResource {
	
	@GET
	@Produces({MediaType.APPLICATION_JSON})
	public Response getPersonListJson() {
		GenericEntity<List<Person>> list 
		= new GenericEntity<List<Person>>(PersonList.persons) { };
		//Adding CORS header for testing. This header should not be in production code
        return Response.ok(list).header("Access-Control-Allow-Origin", "*").build();
	}
}