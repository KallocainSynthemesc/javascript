package api;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import dao.PersonList;
import model.Person;

@Path("/persons")
public class PersonResource {
	
	@GET
	@Produces("application/xml")
	public List<Person> getPersonList() {
        return PersonList.persons;
	}
	
	@GET
	@Path("{id}")
	@Produces("application/xml")
	public Person getPerson(@PathParam("id") int id) {
		Person p = null;
		for(Person pers : PersonList.persons) {
			if(pers.getPersonNum() == id) {
				p = pers;
				break;
			}
		}
		return p;
	}
	
	@POST
	@Produces("application/xml")
	public Person addPerson(@FormParam("firstName") String firstName,
	                        @FormParam("lastName") String lastName,
	                        @FormParam("age") int age) {
		long id = PersonList.persons.size();
	    Person newPers = new Person(id, firstName, lastName, age);
	    PersonList.persons.add(newPers);
	    return newPers;
	}
	
	@DELETE
	@Path("{id}")
	@Produces("application/xml")
	public Person deletePerson(@PathParam("id") int id) {
		Person p = null;
		for(Person pers : PersonList.persons) {
			if(pers.getPersonNum() == id) {
				p = pers;
				break;
			}
		}
		PersonList.persons.remove(p);
		return p;
	}
	
	@PUT
	@Path("{id}")
	public Person updatePerson(@PathParam("id") long id,
	                            @FormParam("firstName") String firstName,
	                            @FormParam("lastName") String lastName,
	                            @FormParam("age") int age) {
		Person p = null;
		for(Person pers : PersonList.persons) {
			if(pers.getPersonNum() == id) {
				pers.setAge(age);
				pers.setFirstName(firstName);
				pers.setLastName(lastName);
				p = pers;
				break;
			}
		}
	    return p;
	}
}