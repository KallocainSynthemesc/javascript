package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import dao.PersonList;
import model.Person;

@WebServlet(
        name = "PersonServlet",
        urlPatterns = {"/persons"}
    )
public class PersonServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static List<Person> persons = PersonList.persons;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");
        
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter = objectMapper.writerWithDefaultPrettyPrinter();
        String json = objectWriter.writeValueAsString(persons);
        PrintWriter out = response.getWriter();
        out.println(json);
    }
	
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");
		final String firstName = request.getParameter("fname");
        final String lastName = request.getParameter("lname");
        final int age = Integer.parseInt(request.getParameter("age"));
        long personNum = persons.size() + 1;
        Person person = new Person(personNum, firstName, lastName, age);
        persons.add(person);
        
        ObjectMapper mapper = new ObjectMapper();
        ObjectWriter objectWriter = mapper.writerWithDefaultPrettyPrinter();
        String json = objectWriter.writeValueAsString(person);
        PrintWriter out = response.getWriter();
        out.println(json);
	}
}