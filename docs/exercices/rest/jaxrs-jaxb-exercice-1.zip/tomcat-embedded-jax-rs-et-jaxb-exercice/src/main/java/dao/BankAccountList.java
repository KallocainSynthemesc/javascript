package dao;

import java.util.ArrayList;
import java.util.List;

import model.BankAccount;

public class BankAccountList {
	
	public static List<BankAccount> bankaccs = new ArrayList<BankAccount>();
	
	static {
		bankaccs.add(new BankAccount(1, PersonList.persons.get(0), PersonList.persons.get(1), "BGE"));
		bankaccs.add(new BankAccount(2, PersonList.persons.get(1), PersonList.persons.get(2), "K"));
    }
}
