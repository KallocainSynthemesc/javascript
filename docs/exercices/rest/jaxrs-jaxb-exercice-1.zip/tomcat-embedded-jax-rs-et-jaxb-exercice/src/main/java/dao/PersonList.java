package dao;

import java.util.ArrayList;
import java.util.List;

import model.Person;

public class PersonList {
	
	public static List<Person> persons = new ArrayList<Person>();
	
	static {
        persons.add(new Person(1L,"Kilian", "Schropp", 28));
        persons.add(new Person(2L, "Alice", "Wonderland", 30));
        persons.add(new Person(3L, "Bob", "Baumeister", 35));
    }
}
