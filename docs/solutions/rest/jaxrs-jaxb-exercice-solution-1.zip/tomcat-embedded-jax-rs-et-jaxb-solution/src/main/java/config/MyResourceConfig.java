package config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;

import api.BankAccountResource;
import api.PersonResource;

import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class MyResourceConfig extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(PersonResource.class);
        classes.add(BankAccountResource.class);
        classes.add(CorsFilter.class);
        return classes;
    }
}