package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import dao.PersonList;
import model.Person;

@WebServlet(
        name = "SinglePersonServlet",
        urlPatterns = {"/persons/*"}
    )
public class SinglePersonServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static List<Person> persons = PersonList.persons;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        setAccessControlHeaders(response);
        String pathInfo = request.getPathInfo();
        Long id;
        try {
	        id = Long.parseLong(pathInfo.substring(1));
	    } catch (NumberFormatException e) {
	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid person ID in request URL");
	        return;
	    }
        
        Person person = persons.stream()
                .filter(pers -> id.equals(pers.getPersonNum()))
                .findAny()
                .orElse(null);
        
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter = objectMapper.writerWithDefaultPrettyPrinter();
        String json = objectWriter.writeValueAsString(person);
        PrintWriter out = response.getWriter();
        out.println(json);
    }
	
	@Override
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		setAccessControlHeaders(response);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.readTree(request.getInputStream());
		
		String firstName = rootNode.get("fname").asText();
		String lastName = rootNode.get("lname").asText();
		int age = rootNode.get("age").asInt();
		
        String pathInfo = request.getPathInfo();
        Long id;
        try {
	        id = Long.parseLong(pathInfo.substring(1));
	    } catch (NumberFormatException e) {
	        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid person ID in request URL");
	        return;
	    }
        
        Person person = persons.stream()
                .filter(pers -> id.equals(pers.getPersonNum()))
                .findAny()
                .orElse(null);
        
        person.setAge(age);
        person.setFirstName(firstName);
        person.setLastName(lastName);
        
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter objectWriter = objectMapper.writerWithDefaultPrettyPrinter();
        String json = objectWriter.writeValueAsString(person);
        PrintWriter out = response.getWriter();
        out.println(json);
	}
	
	//for Preflight
    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        setAccessControlHeaders(resp);
        resp.setStatus(HttpServletResponse.SC_OK);
    }

    private void setAccessControlHeaders(HttpServletResponse resp) {
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "POST,GET,OPTIONS,PUT,DELETE");
        resp.setHeader("Access-Control-Allow-Headers", "*");
    }
}