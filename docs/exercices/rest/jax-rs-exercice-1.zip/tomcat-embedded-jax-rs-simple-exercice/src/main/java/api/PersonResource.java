package api;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import dao.PersonList;
import model.Person;

@Path("/persons")
public class PersonResource {
	
	@GET
	public String getPersonList() {
		System.out.println(PersonList.persons);
		//Adding CORS header for testing. This header should not be in production code
        return PersonList.persons.toString();
	}
	
	@GET
	@Path("{id}")
	public String getPersonById(@PathParam("id") long id) {
		Person resultPers = null;
		////TODO Mettre en �uvre la m�thode getPersonById
		//Adding CORS header for testing. This header should not be in production code
        return resultPers.toString();
	}
	
	@POST
	public String addPerson() {
		Person newPers = null;
		//TODO Mettre en �uvre la m�thode addPerson.
		//Adding CORS header for testing. This header should not be in production code
        return newPers.toString();
	}
}