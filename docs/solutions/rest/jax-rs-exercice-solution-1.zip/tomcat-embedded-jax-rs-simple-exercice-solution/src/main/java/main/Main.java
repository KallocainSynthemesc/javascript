package main;

import java.io.File;
import java.util.Optional;


import org.apache.catalina.LifecycleException;
import org.apache.catalina.startup.Tomcat;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

import config.MyResourceConfig;

import org.apache.catalina.Context;


public class Main {

	public static void startServer() throws LifecycleException {
		System.out.println("From OS Env: Hostname: " + System.getenv("HOSTNAME") + ", PORT: " + System.getenv("PORT"));
		final Optional<String> port = Optional.ofNullable(System.getenv("PORT"));
		String contextPath = "/";
		String appBase = ".";

		Tomcat tomcat = new Tomcat();

		tomcat.setPort(Integer.valueOf(port.orElse("8080")));
		tomcat.getConnector();

		String basePath = new File(appBase).exists() ? new File(appBase).getAbsolutePath() : appBase;

		Context context = tomcat.addWebapp(contextPath, basePath);
		Tomcat.addServlet(context, "jersey-container-servlet",
				new ServletContainer(new ResourceConfig(MyResourceConfig.class)));
		context.addServletMappingDecoded("/api/*", "jersey-container-servlet");
		tomcat.start();
		System.out.println("Server listening on " + tomcat.getHost().getName() + ":" + tomcat.getConnector().getPort());
		tomcat.getServer().await();
	}

	public static void main(String[] args) throws LifecycleException {
		startServer();
	}

}
