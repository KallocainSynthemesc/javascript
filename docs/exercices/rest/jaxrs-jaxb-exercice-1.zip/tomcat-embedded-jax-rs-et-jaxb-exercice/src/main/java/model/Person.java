package model;

import java.util.Objects;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "person")
@XmlAccessorType(XmlAccessType.FIELD)
public class Person {

	@XmlAttribute
	private long personNum;
	
	@XmlElement
    private String firstName;
    
	@XmlElement
    private String lastName;
    
	@XmlElement
    private int age;

    public Person() {}
    
    public Person(long personNum, String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.personNum = personNum;
    }

    public long getPersonNum() {
        return personNum;
    }

    public void setPersonNum(long personNum) {
        this.personNum = personNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getLastName() {
        return this.lastName;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Person)) {
            return false;
        }
        Person otherPerson = (Person) o;
        return personNum == otherPerson.personNum
                && Objects.equals(firstName, otherPerson.firstName)
                && Objects.equals(lastName, otherPerson.lastName);
    }
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + (int) (personNum ^ (personNum >>> 32));
		return result;
	}
    
    @Override
    public String toString() {
    	return "Person [personNum=" + personNum + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}