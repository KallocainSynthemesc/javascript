package config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import com.fasterxml.jackson.jaxrs.xml.JacksonJaxbXMLProvider;

import api.PersonResource;

import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class MyResourceConfig extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(PersonResource.class);
        return classes;
    }

    @Override
    public Set<Object> getSingletons() {
        Set<Object> singletons = new HashSet<Object>();
        JacksonJaxbJsonProvider jacksonJaxbJsonProvider = new JacksonJaxbJsonProvider();
        jacksonJaxbJsonProvider.setMapper(new ObjectMapper());
        JacksonJaxbXMLProvider jacksonJaxbXmlProvider = new JacksonJaxbXMLProvider();
        singletons.add(jacksonJaxbJsonProvider);
        singletons.add(jacksonJaxbXmlProvider);
        return singletons;
    }
}