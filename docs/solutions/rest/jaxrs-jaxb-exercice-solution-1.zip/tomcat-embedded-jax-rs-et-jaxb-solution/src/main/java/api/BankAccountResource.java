package api;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import dao.BankAccountList;
import dao.PersonList;
import model.BankAccount;


@Path("/bankaccount")
public class BankAccountResource {
	
	@GET
	@Produces({"application/xml", "application/json"})
	public List<BankAccount> getBankAccountList(@QueryParam("start") int start, 
			  									@QueryParam("size") int size) {
		if(size <= 0) {
			return BankAccountList.bankaccs;
		}
	    List<BankAccount> result = new ArrayList<BankAccount>();
	    for (int i = start; i < Math.min(start + size, BankAccountList.bankaccs.size()); i++) {
	        result.add(BankAccountList.bankaccs.get(i));
	    }
	    return result;
	}
	
	@GET
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public BankAccount getBankAccount(@PathParam("id") int id) {
		BankAccount a = null;
		for(BankAccount acc : BankAccountList.bankaccs) {
			if(acc.getAccountIdentifier() == id) {
				a = acc;
				break;
			}
		}
		return a;
	}
	
	@DELETE
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public BankAccount deleteBankAccount(@PathParam("id") int id) {
		BankAccount a = null;
		for(BankAccount acc : BankAccountList.bankaccs) {
			if(acc.getAccountIdentifier() == id) {
				a = acc;
				break;
			}
		}
		BankAccountList.bankaccs.remove(a);
		return a;
	}
	
	@POST
	@Produces({"application/xml", "application/json"})
	public BankAccount addBankAccount(@FormParam("accountOwner") long accountOwnerId,
	                        @FormParam("bankConsultant") long bankConsultantId,
	                        @FormParam("bankName") String bankName) {
		int id = BankAccountList.bankaccs.size();
		BankAccount newAcc = new BankAccount(id, PersonList.getPerson(accountOwnerId), PersonList.getPerson(bankConsultantId), bankName);
		BankAccountList.bankaccs.add(newAcc);
	    return newAcc;
	}
	
	@PUT
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public BankAccount updatePerson(@PathParam("id") long id, @FormParam("accountOwner") long accountOwnerId,
			@FormParam("bankConsultant") long bankConsultantId, @FormParam("bankName") String bankName) {
		BankAccount a = null;
		for (BankAccount acc : BankAccountList.bankaccs) {
			if (acc.getAccountIdentifier() == id) {
				acc.setAccountOwner(PersonList.getPerson(accountOwnerId));
				acc.setBankConsultant(PersonList.getPerson(bankConsultantId));
				acc.setBankName(bankName);
				a = acc;
				break;
			}
		}
		return a;
	}
}