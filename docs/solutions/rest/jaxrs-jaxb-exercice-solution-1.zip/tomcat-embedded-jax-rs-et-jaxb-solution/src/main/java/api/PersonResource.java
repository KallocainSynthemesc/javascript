package api;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import dao.PersonList;
import model.Person;

@Path("/persons")
public class PersonResource {
	
	@GET
	@Produces({ "application/xml", "application/json" })
	public List<Person> getPersonList(@QueryParam("start") int start, 
									  @QueryParam("size") int size) {
		if(size <= 0) {
			return PersonList.persons;
		}
	    List<Person> result = new ArrayList<Person>();
	    for (int i = start; i < Math.min(start + size, PersonList.persons.size()); i++) {
	        result.add(PersonList.persons.get(i));
	    }
	    return result;
	}
	
	@GET
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public Person getPerson(@PathParam("id") int id) {
		return PersonList.getPerson(id);
	}
	
	@POST
	@Produces({"application/xml", "application/json"})
	public Person addPerson(@FormParam("firstName") String firstName,
	                        @FormParam("lastName") String lastName,
	                        @FormParam("age") int age) {
		long id = PersonList.persons.size();
	    Person newPers = new Person(id, firstName, lastName, age);
	    PersonList.persons.add(newPers);
	    return newPers;
	}
	
	@DELETE
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public Person deletePerson(@PathParam("id") int id) {
		Person p = PersonList.getPerson(id);
		PersonList.persons.remove(p);
		return p;
	}
	
	@PUT
	@Path("{id}")
	@Produces({"application/xml", "application/json"})
	public Person updatePerson(@PathParam("id") long id,
	                            @FormParam("firstName") String firstName,
	                            @FormParam("lastName") String lastName,
	                            @FormParam("age") int age) {
		Person p = null;
		for(Person pers : PersonList.persons) {
			if(pers.getPersonNum() == id) {
				pers.setAge(age);
				pers.setFirstName(firstName);
				pers.setLastName(lastName);
				p = pers;
				break;
			}
		}
	    return p;
	}
}